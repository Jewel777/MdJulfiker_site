using System.Diagnostics;
using Julfiker_Portfolio.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace Julfiker_Portfolio.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            // Example data you might want to pass to the View
            ViewData["Name"] = "Md Julfiker Ali Jewel";
            ViewData["Title"] = "Portfolio Website";

            return View();
        }

        public IActionResult Resume()
        {
            return View();
        }

        public IActionResult Publications()
        {
            return View();
        }

        public IActionResult Education()
        {
            return View();
        }

        public IActionResult Skills()
        {
            return View();
        }

        public IActionResult Experience()
        {
            return View();
        }

        public IActionResult Projects()
        {
            return View();
        }

        public IActionResult Research()
        {
            return View();
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult Activities()
        {
            return View(); // Add a new view to display activities.
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
