using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Julfiker_Portfolio.Views.Home
{
    public class ResearchModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
