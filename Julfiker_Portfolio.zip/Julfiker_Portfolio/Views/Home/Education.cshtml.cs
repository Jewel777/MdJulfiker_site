using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Julfiker_Portfolio.Views.Home
{
    public class EducationModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
